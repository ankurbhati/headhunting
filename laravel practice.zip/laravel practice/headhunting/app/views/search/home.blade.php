@extends('layouts.adminLayout')
@section('content')
<p>Dashboard Home</p>
<h2>Welcome to Portal Add Template</h2>
@stop