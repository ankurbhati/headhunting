<footer class="main-footer">
        <div class="pull-right hidden-xs">
          <b>Version</b> 2.3.0
        </div>
        <strong>Copyright &copy; 2015-2016 <a href="http://www.cipherwheel.com">Cipher Wheel Solutions</a>.</strong> All rights reserved.
      </footer>